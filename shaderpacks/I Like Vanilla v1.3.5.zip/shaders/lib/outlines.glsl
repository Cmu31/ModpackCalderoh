//float getOutlineAmount() {
	
//	// implements difference of gaussians
//	float depth1 = 0.0;
//	float depth2 = 0.0;
//	float sample;
//	sample  = toLinearDepth(texelFetch(DEPTH_BUFFER_WO_TRANS, texelcoord + ivec2(-1, -1), 0).r);
//	sample += toLinearDepth(texelFetch(DEPTH_BUFFER_WO_TRANS, texelcoord + ivec2( 1, -1), 0).r);
//	sample += toLinearDepth(texelFetch(DEPTH_BUFFER_WO_TRANS, texelcoord + ivec2(-1,  1), 0).r);
//	sample += toLinearDepth(texelFetch(DEPTH_BUFFER_WO_TRANS, texelcoord + ivec2( 1,  1), 0).r);
//	depth1 += sample * 0.801;
//	depth2 += sample * 0.726;
//	sample  = toLinearDepth(texelFetch(DEPTH_BUFFER_WO_TRANS, texelcoord + ivec2( 0, -1), 0).r);
//	sample += toLinearDepth(texelFetch(DEPTH_BUFFER_WO_TRANS, texelcoord + ivec2(-1,  0), 0).r);
//	sample += toLinearDepth(texelFetch(DEPTH_BUFFER_WO_TRANS, texelcoord + ivec2( 1,  0), 0).r);
//	sample += toLinearDepth(texelFetch(DEPTH_BUFFER_WO_TRANS, texelcoord + ivec2( 0,  1), 0).r);
//	depth1 += sample * 0.895;
//	depth2 += sample * 0.852;
//	sample  = toLinearDepth(texelFetch(DEPTH_BUFFER_WO_TRANS, texelcoord, 0).r);
//	depth1 += sample;
//	depth2 += sample;
//	depth1 /= 7.784;
//	depth2 /= 7.312;
	
//	float diff = abs(depth1 - depth2) * far;
//	return smoothstep(0.01, 0.025, diff);
//}



float getOutlineAmount() {
	
	float m = toLinearDepth(texelFetch(DEPTH_BUFFER_WO_TRANS, texelcoord + ivec2( 0,  0), 0).r);
	if (m == 1.0) {return 0.0;}
	m *= far;
	float tl = toLinearDepth(texelFetch(DEPTH_BUFFER_WO_TRANS, texelcoord + ivec2(-1, -1), 0).r) * far;
	float t  = toLinearDepth(texelFetch(DEPTH_BUFFER_WO_TRANS, texelcoord + ivec2( 0, -1), 0).r) * far;
	float tr = toLinearDepth(texelFetch(DEPTH_BUFFER_WO_TRANS, texelcoord + ivec2( 1, -1), 0).r) * far;
	float l  = toLinearDepth(texelFetch(DEPTH_BUFFER_WO_TRANS, texelcoord + ivec2(-1,  0), 0).r) * far;
	float r  = toLinearDepth(texelFetch(DEPTH_BUFFER_WO_TRANS, texelcoord + ivec2( 1,  0), 0).r) * far;
	float bl = toLinearDepth(texelFetch(DEPTH_BUFFER_WO_TRANS, texelcoord + ivec2(-1,  1), 0).r) * far;
	float b  = toLinearDepth(texelFetch(DEPTH_BUFFER_WO_TRANS, texelcoord + ivec2( 0,  1), 0).r) * far;
	float br = toLinearDepth(texelFetch(DEPTH_BUFFER_WO_TRANS, texelcoord + ivec2( 1,  1), 0).r) * far;
	
	float lineA = (tl - m) + (br - m);
	float lineB = (tr - m) + (bl - m);
	float lineC = (t - m) + (b - m);
	float lineD = (l - m) + (r - m);
	float total = lineA + lineB + lineC + lineD;
	
	return clamp(abs(total * inversesqrt(m)), 0.0, 1.0);
}
