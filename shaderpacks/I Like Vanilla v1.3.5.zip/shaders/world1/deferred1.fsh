#version 140

#define SHADER_DEFERRED1
#define END
#define FSH

#include "/basics/settings.glsl"
#include "/basics/uniforms.glsl"
#include "/generated/common.glsl"
#include "/basics/common.glsl"

#include "/program/deferred1.glsl"
